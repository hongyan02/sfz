'use client';

import React, { useEffect, useState, useMemo } from 'react';
import { Table, Typography, Spin, Empty } from 'antd';
import { useSearchStore } from '../store';
import { fetchResultParams } from '../services/api';

const { Text } = Typography;

/**
 * 工序表格组件
 * @param {Object} props
 * @param {string|string[]} props.processName - 工艺流程代码，可以是单个值或数组
 * @param {Object} [props.style] - 自定义样式
 */
const ProcessTable = ({ processName, style = {} }) => {
  const { material_lot_code } = useSearchStore();
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState([]);
  const [error, setError] = useState(null);
  
  // 使用 useMemo 缓存 processNames 数组，避免每次渲染都创建新数组
  const processNames = useMemo(() => {
    return Array.isArray(processName) ? processName : [processName];
  }, [processName]);
  
  // 获取数据
  useEffect(() => {
    const fetchData = async () => {
      if (!material_lot_code) {
        setData([]);
        return;
      }
      
      setLoading(true);
      setError(null);
      
      try {
        // 为每个 processName 获取实际数据
        const allData = [];
        
        for (const name of processNames) {
          try {
            // 调用 API 获取结果参数数据
            const result = await fetchResultParams(name, material_lot_code);
            
            if (result && result.items && Array.isArray(result.items)) {
              // 根据工艺代码获取工艺名称
              const processDisplayName = getProcessName(name);
              
              // 将所有数据统一使用"结果参数"作为参数类型
              allData.push(...result.items.map(item => ({
                key: `${name}-结果参数-${item.name}`,
                process: processDisplayName,
                paramType: '结果参数',
                name: item.name,
                value: item.value,
              })));
            }
          } catch (err) {
            console.error(`获取工艺 ${name} 的数据失败:`, err);
            // 继续处理其他工艺，不中断整个循环
          }
        }
        
        setData(allData);
      } catch (err) {
        console.error('获取工序数据失败:', err);
        setError('获取数据失败，请稍后重试');
      } finally {
        setLoading(false);
      }
    };
    
    fetchData();
  }, [material_lot_code, processNames]);
  
  // 处理单元格合并
  const mergedCellsConfig = useMemo(() => {
    const config = {};
    
    // 计算需要合并的单元格
    if (data.length > 0) {
      // 按工序和参数类型分组
      const groups = {};
      
      data.forEach((item, index) => {
        const key = `${item.process}-${item.paramType}`;
        if (!groups[key]) {
          groups[key] = {
            startIndex: index,
            count: 0,
          };
        }
        groups[key].count++;
      });
      
      // 设置合并配置
      config.onCell = (record, rowIndex) => {
        const key = `${record.process}-${record.paramType}`;
        const group = groups[key];
        
        if (rowIndex === group.startIndex) {
          return {
            rowSpan: group.count,
            style: { 
              verticalAlign: 'middle',
              whiteSpace: 'nowrap'
            }
          };
        }
        
        if (rowIndex > group.startIndex && rowIndex < group.startIndex + group.count) {
          return { rowSpan: 0 };
        }
        
        return { style: { whiteSpace: 'nowrap' } };
      };
    }
    
    return config;
  }, [data]);
  
  // 表格列定义
  const columns = useMemo(() => [
    {
      title: '工序',
      dataIndex: 'process',
      key: 'process',
      width: 'auto',
      ellipsis: false,
      ...mergedCellsConfig,
    },
    {
      title: '参数类型',
      dataIndex: 'paramType',
      key: 'paramType',
      width: 'auto',
      ellipsis: false,
      ...mergedCellsConfig,
    },
    {
      title: '采集项名称',
      dataIndex: 'name',
      key: 'name',
      width: 'auto',
      ellipsis: false,
      onCell: () => ({
        style: { whiteSpace: 'nowrap' }
      })
    },
    {
      title: '数据结果',
      dataIndex: 'value',
      key: 'value',
      width: 'auto',
      ellipsis: false,
      render: (text) => <Text style={{ whiteSpace: 'nowrap' }}>{text}</Text>,
      onCell: () => ({
        style: { whiteSpace: 'nowrap' }
      })
    },
  ], [mergedCellsConfig]);
  
  // 渲染表格或加载状态
  const renderContent = () => {
    if (loading) {
      return (
        <div style={{ textAlign: 'center', padding: '20px 0' }}>
          <Spin size="default" />
        </div>
      );
    }
    
    if (error) {
      return (
        <div style={{ textAlign: 'center', padding: '20px 0', color: '#ff4d4f' }}>
          {error}
        </div>
      );
    }
    
    if (!material_lot_code) {
      return (
        <Empty 
          image={Empty.PRESENTED_IMAGE_SIMPLE} 
          description="请输入电芯条码"
        />
      );
    }
    
    if (data.length === 0) {
      return (
        <Empty 
          image={Empty.PRESENTED_IMAGE_SIMPLE} 
          description="无数据"
        />
      );
    }
    
    return (
      <Table 
        columns={columns} 
        dataSource={data} 
        pagination={false}
        size="small"
        bordered
        style={{ width: 'auto' }}
        scroll={{ x: 'max-content' }}
        tableLayout="auto"
      />
    );
  };
  
  return (
    <div style={{ width: '100%', overflow: 'auto', ...style }}>
      {renderContent()}
    </div>
  );
};

/**
 * 获取工艺名称
 * @param {string} code - 工艺代码
 * @returns {string} - 工艺名称
 */
function getProcessName(code) {
  const processMap = {
    C021: "正极搅拌",
    C022: "陶瓷搅拌",
    C023: "底涂搅拌",
    C030: "正极涂布",
    C040: "正极辊分",
    A020: "负极搅拌",
    A030: "负极涂布",
    A040: "负极辊分",
    S010: "切叠热压",
    E010: "X-Ray01",
    E020: "极耳预焊",
    E030: "极耳终焊",
    E040: "盖板&连接片焊接前",
    E050: "包PET膜",
    E060: "入壳预焊",
    E070: "盖板满焊",
    E080: "X-Ray02",
    E090: "前氦检",
    E100: "真空烘烤",
    E110: "一次注液",
    F010: "高温静置1",
    F020: "OCV0",
    F030: "拔化成钉",
    F040: "化成",
    F050: "入化成钉",
    F060: "高温静置2",
    F070: "OCV1",
    F080: "二次注液",
    F090: "密封钉焊接",
    F100: "后氦检",
    F110: "加拘束1",
    F120: "SOC调整",
    F130: "高温静置3",
    F140: "常温静置1",
    F150: "OCV2",
    F160: "常温静置2",
    F170: "OCV3",
    F180: "加拘束2",
    F190: "分容",
    F200: "常温静置3",
    F210: "OCV4",
    F220: "常温静置4",
    F230: "OCV5",
    F240: "常温静置5",
    F250: "OCV6",
    F260: "DCIR",
    F270: "常温静置6"
  };
  
  return processMap[code] || code;
}

export default ProcessTable; 