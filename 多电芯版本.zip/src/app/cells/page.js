'use client';

import TwoColumnTable from '../../components/cells/TwoColumnTable';
import { useSearchStore, useProcessDataStore } from '../../store';

export default function CellsPage() {
  // 从不同的 store 获取数据和方法
  const { material_lot_code } = useSearchStore();
  const { error } = useProcessDataStore();

  // 使用硬编码的material_lot_code值进行测试
  const testMaterialLotCode = "04QCB30601000JF480001246";

  // 简化的数据结构 - 只需要 title 和基本的 processName、title 参数
  const tableData = [
    {
      title: '原材料',
      content: { props: { processName: null, title: '原材料' } }
    },
    {
      title: '浆料',
      content: { props: { processName: "C021", title: "正极浆料" } }
    },
    {
      title: '涂布卷',
      content: { props: { processName: "C030", title: "正极涂布卷" } }
    },
    {
      title: '辊分卷',
      content: { props: { processName: "C040", title: "正极辊分卷" } }
    },
    {
      title: 'A芯包',
      content: { props: { processName: "S010", title: "A芯包" } }
    },
    {
      title: 'B芯包',
      content: { props: { processName: "S010", title: "B芯包" } }
    },
    {
      title: '双芯包',
      content: { props: { processName: "E030", title: "双芯包" } }
    },
    {
      title: '裸电芯',
      content: { props: { processName: "E040", title: "裸电芯" } }
    },
    {
      title: '电芯',
      content: { props: { processName: "F100", title: "电芯" } }
    }
  ];

  return (
    <div className="h-screen flex flex-col overflow-hidden">
      <div className="flex-1 p-6 overflow-auto">
        <div className="w-full">
          <h1 className="text-2xl font-bold mb-6 text-gray-800">电池数据管理</h1>
          <div className="w-full overflow-x-auto">
            <TwoColumnTable 
              data={tableData} 
              material_lot_code={testMaterialLotCode}
            />
          </div>
        </div>
      </div>
    </div>
  );
} 