/**
 * 处理物料终点请求
 */

/**
 * 处理 POST 请求，获取物料终点数据
 * @param {Request} request - 请求对象
 * @returns {Response} - 响应对象
 */
export async function POST(request) {
  try {
    // 解析请求体
    const body = await request.json();
    const { material_lot_code, workcell_id } = body;

    // 验证必要参数
    if (!material_lot_code) {
      return Response.json({ error: '缺少必要参数 material_lot_code' }, { status: 400 });
    }

    // 调用外部 API
    const apiUrl = 'http://10.22.161.62:8083/api/5m1e/material-end';
    
    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        material_lot_code,
        workcell_id: workcell_id || '', // 如果没有提供 workcell_id，则发送空字符串
      }),
      // 如果外部 API 需要较长时间响应，设置较长的超时时间
      signal: AbortSignal.timeout(10000), // 10秒超时
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('API 请求失败:', response.status, errorText);
      return Response.json(
        { error: `API 请求失败: ${response.status}`, details: errorText },
        { status: response.status }
      );
    }

    // 获取 API 响应数据
    const data = await response.json();

    // 返回响应数据
    return Response.json(data);
  } catch (error) {
    console.error('处理请求失败:', error);
    return Response.json(
      { error: '服务器内部错误', message: error.message },
      { status: 500 }
    );
  }
} 