// 基础 API 地址
const BASE_URL = 'http://10.22.161.62:8083';

/**
 * 处理 POST 请求，获取芯包码数据
 * @param {Request} request - 请求对象
 * @returns {Response} - 响应对象
 */
export async function POST(request) {
  try {
    // 解析请求体
    const body = await request.json();
    const { material_lot_code, operation_name } = body;

    // 验证必要参数
    if (!material_lot_code || !operation_name) {
      return Response.json({ error: '缺少必要参数' }, { status: 400 });
    }

    // 转发请求到外部 API
    const response = await fetch(`${BASE_URL}/api/5m1e/coreBagCode`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        material_lot_code,
        operation_name,
      }),
    });

    // 检查响应状态
    if (!response.ok) {
      return Response.json(
        { error: `外部 API 请求失败: ${response.status}` },
        { status: response.status }
      );
    }

    // 返回响应数据
    const data = await response.json();
    return Response.json(data);
  } catch (error) {
    console.error('处理请求失败:', error);
    return Response.json(
      { error: '服务器内部错误', message: error.message },
      { status: 500 }
    );
  }
} 