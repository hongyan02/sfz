'use client';

import { useState } from 'react';
import { Space, Tag, Divider, Card } from 'antd';
import TwoColumnTable from '../../components/cells/TwoColumnTable';
import ExcelImportButton from '../../components/ExcelImportButton';
import ExcelExportButton from '../../components/ExcelExportButton';
import { useSearchStore, useProcessDataStore } from '../../store';

export default function CellsPage() {
  // 从不同的 store 获取数据和方法
  const { material_lot_code } = useSearchStore();
  const { error } = useProcessDataStore();
  
  // 新增状态来存储导入的电芯条码数据
  const [importedBarcodes, setImportedBarcodes] = useState([]);

  // 使用硬编码的material_lot_code值进行测试
  // const testMaterialLotCode = "04QCB30601000JF480001246";

  // 处理Excel导入的回调函数
  const handleDataImported = (barcodes) => {
    setImportedBarcodes(barcodes);
    console.log('导入的电芯条码:', barcodes);
  };

  // 准备导出数据格式
  const prepareExportData = () => {
    return importedBarcodes.map(barcode => ({
      barcode: barcode,
      tableData: tableData
    }));
  };

  // 简化的数据结构 - 只需要 title 和基本的 processName、title 参数
  const tableData = [
    {
      title: '原材料',
      content: { props: { processName: null, title: '原材料' } }
    },
    {
      title: '浆料',
      content: { props: { processName: "C021", title: "正极浆料" } }
    },
    {
      title: '涂布卷',
      content: { props: { processName: "C030", title: "正极涂布卷" } }
    },
    {
      title: '辊分卷',
      content: { props: { processName: "C040", title: "正极辊分卷" } }
    },
    {
      title: 'A芯包',
      content: { props: { processName: "S010", title: "A芯包" } }
    },
    {
      title: 'B芯包',
      content: { props: { processName: "S010", title: "B芯包" } }
    },
    {
      title: '双芯包',
      content: { props: { processName: "E030", title: "双芯包" } }
    },
    {
      title: '裸电芯',
      content: { props: { processName: "E040", title: "裸电芯" } }
    },
    {
      title: '电芯',
      content: { props: { processName: "F100", title: "电芯" } }
    }
  ];

  return (
    <div className="min-h-screen flex flex-col">
      {/* 顶部固定区域 - 不受表格宽度影响 */}
      <div className="flex-shrink-0 p-6 bg-white border-b border-gray-200">
        <div className="max-w-full">
          {/* 页面标题和操作按钮区域 */}
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-2xl font-bold text-gray-800">电池数据管理</h1>
            <div className="flex gap-3">
              <ExcelImportButton 
                onDataImported={handleDataImported}
                buttonText="导入电芯条码"
                style={{ fontSize: '14px' }}
              />
              <ExcelExportButton 
                exportData={prepareExportData()}
                filename="电池数据管理"
                buttonText="导出Excel"
                style={{ fontSize: '14px' }}
              />
            </div>
          </div>
          
          {/* 导入数据显示区域 */}
          {importedBarcodes.length > 0 && (
            <div className="mb-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-lg font-medium text-blue-800">
                  已导入的电芯条码
                </h3>
                <Tag color="blue" style={{ fontSize: '12px' }}>
                  共 {importedBarcodes.length} 个条码
                </Tag>
              </div>
              <div className="max-h-32 overflow-y-auto">
                <Space size={[8, 8]} wrap>
                  {importedBarcodes.map((barcode, index) => (
                    <Tag 
                      key={index} 
                      color="processing"
                      style={{ 
                        fontFamily: 'monospace', 
                        fontSize: '11px',
                        marginBottom: '4px'
                      }}
                    >
                      {barcode}
                    </Tag>
                  ))}
                </Space>
              </div>
            </div>
          )}
          
          <Divider style={{ margin: '0' }} />
        </div>
      </div>

      {/* 表格区域 - 可横向滚动 */}
      <div className="flex-1 overflow-hidden">
        <div 
          className="overflow-x-auto overflow-y-auto"
          style={{ 
            height: 'calc(100vh - 250px)', // 减去顶部固定区域的大概高度
            minHeight: '400px' 
          }}
        >
          <div className="p-6" style={{ minWidth: 'max-content' }}>
            {/* 根据导入的条码动态创建表格组件 */}
            {importedBarcodes.length > 0 ? (
              <div className="space-y-8">
                {importedBarcodes.map((barcode, index) => (
                  <Card
                    key={`barcode-${index}`}
                    title={
                      <div className="flex items-center justify-between">
                        <span className="text-lg font-medium">
                          电芯条码: <code className="bg-gray-100 px-2 py-1 rounded text-sm font-mono">{barcode}</code>
                        </span>
                        <Tag color="green">第 {index + 1} 个</Tag>
                      </div>
                    }
                    size="small"
                    style={{ 
                      marginBottom: '24px',
                      border: '2px solid #e5e7eb',
                      borderRadius: '8px',
                      width: 'fit-content',
                      minWidth: '800px'
                    }}
                    styles={{
                      header: {
                        backgroundColor: '#f9fafb',
                        borderBottom: '1px solid #e5e7eb'
                      }
                    }}
                  >
                    <TwoColumnTable 
                      data={tableData} 
                      material_lot_code={barcode}
                    />
                  </Card>
                ))}
              </div>
            ) : (
              /* 提示用户导入Excel文件 */
              <div className="text-center py-16">
                <div className="max-w-md mx-auto">
                  <div className="text-6xl mb-4">📊</div>
                  <h3 className="text-xl font-medium text-gray-600 mb-2">
                    暂无数据
                  </h3>
                  <p className="text-gray-500 mb-4">
                    请点击上方的"导入电芯条码"按钮，导入Excel文件中的电芯条码数据
                  </p>
                  <div className="text-sm text-gray-400">
                    <p>支持的文件格式：.xlsx, .xls</p>
                    <p>系统将自动解析所有工作表中的条码数据</p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
} 