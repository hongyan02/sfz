'use client';

import '@ant-design/v5-patch-for-react-19'; 
import React, { useState } from 'react';
import { Button, message, Progress } from 'antd';
import { DownloadOutlined } from '@ant-design/icons';
import * as XLSX from 'xlsx';

/**
 * Excel导出按钮组件 - 增强版，包含详细的API数据
 * @param {Object} props
 * @param {Array} [props.exportData] - 要导出的数据数组，包含条码和对应的表格数据
 * @param {string} [props.filename] - 导出文件名
 * @param {Object} [props.style] - 按钮样式
 * @param {string} [props.buttonText] - 按钮文本
 */
const ExcelExportButton = ({ 
  exportData = [],
  filename = '电池数据管理',
  style = {},
  buttonText = '导出Excel'
}) => {
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState(0);

  // 获取原材料数据
  const fetchMaterialData = async (material_lot_code) => {
    try {
      const [positiveRes, ceramicRes, negativeRes] = await Promise.all([
        fetch('/api/materialPro', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            material_lot_code: material_lot_code,
            operation_name: 'C021' // 正极浆料
          }),
        }),
        fetch('/api/materialPro', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            material_lot_code: material_lot_code,
            operation_name: 'C022' // 陶瓷浆料
          }),
        }),
        fetch('/api/materialPro', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            material_lot_code: material_lot_code,
            operation_name: 'A020' // 负极浆料
          }),
        })
      ]);

      const [positiveData, ceramicData, negativeData] = await Promise.all([
        positiveRes.ok ? positiveRes.json() : { Material: [] },
        ceramicRes.ok ? ceramicRes.json() : { Material: [] },
        negativeRes.ok ? negativeRes.json() : { Material: [] }
      ]);

      return {
        positive: positiveData.Material || [],
        ceramic: ceramicData.Material || [],
        negative: negativeData.Material || []
      };
    } catch (error) {
      console.error('获取原材料数据失败:', error);
      return { positive: [], ceramic: [], negative: [] };
    }
  };

  // 获取条码数据
  const fetchCoreBagCodes = async (material_lot_code, operation_name) => {
    if (!operation_name) return [];
    
    try {
      const response = await fetch('/api/coreBagCode', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          material_lot_code: material_lot_code,
          operation_name: operation_name,
        }),
      });

      if (!response.ok) return [];
      const data = await response.json();
      return data.coreBagCode || [];
    } catch (error) {
      console.error('获取条码数据失败:', error);
      return [];
    }
  };

  // 获取结果参数数据
  const fetchResultParams = async (material_lot_code, operation_name) => {
    if (!operation_name) return [];
    
    try {
      const response = await fetch('/api/resultParams', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          material_lot_code: material_lot_code,
          operation_name: operation_name,
        }),
      });

      if (!response.ok) return [];
      const data = await response.json();
      return data.rawData || [];
    } catch (error) {
      console.error('获取结果参数数据失败:', error);
      return [];
    }
  };

  // 处理Excel导出
  const handleExport = async () => {
    if (exportData.length === 0) {
      message.warning('暂无数据可导出，请先导入电芯条码');
      return;
    }

    setLoading(true);
    setProgress(0);
    
    try {
      const workbook = XLSX.utils.book_new();
      const totalBarcodes = exportData.length;
      
      // 为每个电芯条码创建详细的工作表
      for (let index = 0; index < exportData.length; index++) {
        const { barcode, tableData } = exportData[index];
        
        // 更新进度
        setProgress(Math.round((index / totalBarcodes) * 100));
        
        // 获取原材料数据
        const materialData = await fetchMaterialData(barcode);
        
        // 创建工作表数据
        const worksheetData = [
          ['电芯条码', barcode],
          ['导出时间', new Date().toLocaleString('zh-CN')],
          [''],
          
          // 原材料部分
          ['=== 原材料 ===']
        ];
        
        // 准备横向数据结构
        const materialHeaders = []; // 原材料名称行（正极浆料、陶瓷浆料、负极浆料）
        const materialNames = [];   // 物料名称行
        const materialCodes = [];   // 物料批次行
        
        // 按顺序处理每种浆料类型的所有物料
        const materialTypes = [
          { name: '正极浆料', data: materialData.positive || [] },
          { name: '陶瓷浆料', data: materialData.ceramic || [] },
          { name: '负极浆料', data: materialData.negative || [] }
        ];
        
        materialTypes.forEach(type => {
          if (type.data.length === 0) {
            // 如果该类型没有数据，至少显示一列
            materialHeaders.push(type.name);
            materialNames.push('暂无数据');
            materialCodes.push('暂无数据');
          } else {
            // 为该类型的每个物料添加一列
            type.data.forEach(material => {
              materialHeaders.push(type.name);
              materialNames.push(material.MATERIAL_NAME || '暂无数据');
              materialCodes.push(material.MATERIAL_LOT_CODE || '暂无数据');
            });
          }
        });
        
        // 添加到工作表数据
        worksheetData.push(materialHeaders); // 第一行：正极浆料、陶瓷浆料、负极浆料...
        worksheetData.push(materialNames);   // 第二行：物料名称
        worksheetData.push(materialCodes);   // 第三行：物料批次
        
        worksheetData.push(['']); // 空行
        
        // 处理其他工艺流程
        for (const process of tableData) {
          if (process.content?.props?.processName) {
            const processName = process.content.props.processName;
            const processTitle = process.title;
            
            // 获取条码数据和结果参数
            const [coreBagCodes, resultParams] = await Promise.all([
              fetchCoreBagCodes(barcode, processName),
              fetchResultParams(barcode, processName)
            ]);
            
            // 添加工艺标题
            worksheetData.push([`=== ${processTitle} ===`]);
            
            // 添加条码信息
            if (coreBagCodes.length > 0) {
              worksheetData.push(['条码数据']);
              coreBagCodes.forEach((code, codeIndex) => {
                worksheetData.push([`条码${codeIndex + 1}`, code]);
              });
            } else {
              worksheetData.push(['条码数据', '暂无数据']);
            }
            
            worksheetData.push(['']); // 空行
            
            // 添加结果参数
            if (resultParams.length > 0) {
              worksheetData.push(['结果参数']);
              
              // 准备横向数据结构
              const paramTypes = [];     // 参数类型行
              const paramColumns = [];   // 采集项名称行
              const paramResults = [];   // 数据结果行
              
              // 处理每个结果参数
              resultParams.forEach(param => {
                paramTypes.push('结果参数');
                paramColumns.push(param.columns || '暂无数据');
                
                // 处理数据结果
                if (Array.isArray(param.rows)) {
                  // 如果是数组，取第一个值或合并显示
                  paramResults.push(param.rows.length > 0 ? param.rows.join(', ') : '暂无数据');
                } else {
                  // 如果是单个值
                  paramResults.push(param.rows || '暂无数据');
                }
              });
              
              // 添加到工作表数据
              worksheetData.push(paramTypes);   // 第一行：参数类型
              worksheetData.push(paramColumns); // 第二行：采集项名称
              worksheetData.push(paramResults); // 第三行：数据结果
            } else {
              worksheetData.push(['结果参数', '暂无数据']);
            }
            
            worksheetData.push(['']); // 工艺间空行
          }
        }
        
        // 创建工作表
        const worksheet = XLSX.utils.aoa_to_sheet(worksheetData);
        
        // 设置列宽
        const maxCols = Math.max(...worksheetData.map(row => row.length));
        worksheet['!cols'] = Array(maxCols).fill(0).map(() => ({ width: 20 }));
        
        // 工作表名称
        const sheetName = `电芯${index + 1}_${barcode.slice(0, 10)}`;
        XLSX.utils.book_append_sheet(workbook, worksheet, sheetName);
      }
      
      // 创建汇总工作表
      const summaryData = [
        ['电池数据管理系统 - 详细数据导出报告'],
        [''],
        ['导出时间', new Date().toLocaleString('zh-CN')],
        ['电芯总数', exportData.length],
        ['数据类型', '原材料、工艺条码、结果参数'],
        [''],
        ['序号', '电芯条码', '工艺流程数量'],
        ...exportData.map((item, index) => [
          index + 1,
          item.barcode,
          item.tableData.length
        ])
      ];
      
      const summaryWorksheet = XLSX.utils.aoa_to_sheet(summaryData);
      summaryWorksheet['!cols'] = [
        { width: 8 },   // 序号
        { width: 25 },  // 电芯条码
        { width: 15 }   // 工艺流程数量
      ];
      
      // 将汇总表添加到工作簿的第一个位置
      XLSX.utils.book_append_sheet(workbook, summaryWorksheet, '汇总');
      
      // 生成文件名
      const timestamp = new Date().toISOString().split('T')[0];
      const finalFilename = `${filename}_详细数据_${timestamp}.xlsx`;
      
      // 导出文件
      XLSX.writeFile(workbook, finalFilename);
      
      setProgress(100);
      message.success(`Excel文件导出成功！包含${exportData.length}个电芯的详细数据`);
      
    } catch (error) {
      console.error('Excel导出失败:', error);
      message.error('Excel导出失败，请重试');
    } finally {
      setLoading(false);
      setTimeout(() => setProgress(0), 2000); // 2秒后重置进度
    }
  };

  return (
    <div style={{ position: 'relative' }}>
      <Button 
        type="default" 
        icon={<DownloadOutlined />}
        loading={loading}
        onClick={handleExport}
        style={style}
        disabled={exportData.length === 0}
      >
        {buttonText}
      </Button>
      
      {loading && (
        <div style={{ 
          position: 'absolute', 
          top: '100%', 
          left: 0, 
          right: 0, 
          marginTop: '8px',
          zIndex: 1000
        }}>
          <Progress 
            percent={progress} 
            size="small" 
            format={(percent) => `${percent}%`}
          />
        </div>
      )}
    </div>
  );
};

export default ExcelExportButton; 