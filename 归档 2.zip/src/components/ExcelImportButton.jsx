'use client';

import React, { useState, useRef } from 'react';
import { Button, message, Upload, Modal, Table, Tag } from 'antd';
import { UploadOutlined, FileExcelOutlined } from '@ant-design/icons';
import * as XLSX from 'xlsx';
import '@ant-design/v5-patch-for-react-19'; 

/**
 * Excel导入按钮组件
 * @param {Object} props
 * @param {Function} [props.onDataImported] - 数据导入成功后的回调函数，接收解析出的条码数组
 * @param {Object} [props.style] - 按钮样式
 * @param {string} [props.buttonText] - 按钮文本
 */
const ExcelImportButton = ({ 
  onDataImported,
  style = {},
  buttonText = '导入Excel文件'
}) => {
  const [loading, setLoading] = useState(false);
  const [previewVisible, setPreviewVisible] = useState(false);
  const [previewData, setPreviewData] = useState([]);
  const [barcodeData, setBarcodeData] = useState([]);
  const fileInputRef = useRef(null);

  // 处理文件选择
  const handleFileSelect = (file) => {
    setLoading(true);
    
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target.result);
        const workbook = XLSX.read(data, { type: 'array' });
        
        // 解析所有工作表
        const allBarcodes = [];
        const previewTableData = [];
        
        workbook.SheetNames.forEach((sheetName, sheetIndex) => {
          const worksheet = workbook.Sheets[sheetName];
          const jsonData = XLSX.utils.sheet_to_json(worksheet, { 
            header: 1, // 使用数组格式，保留所有单元格
            defval: '' // 空单元格默认值
          });
          
          // 遍历所有单元格，提取非空数据作为条码
          jsonData.forEach((row, rowIndex) => {
            if (Array.isArray(row)) {
              row.forEach((cell, colIndex) => {
                if (cell && cell.toString().trim()) {
                  const barcode = cell.toString().trim();
                  allBarcodes.push(barcode);
                  
                  // 为预览表格准备数据
                  previewTableData.push({
                    key: `${sheetIndex}-${rowIndex}-${colIndex}`,
                    sheet: sheetName,
                    row: rowIndex + 1,
                    column: String.fromCharCode(65 + colIndex), // A, B, C...
                    barcode: barcode
                  });
                }
              });
            }
          });
        });
        
        // 去重
        const uniqueBarcodes = [...new Set(allBarcodes)];
        
        setBarcodeData(uniqueBarcodes);
        setPreviewData(previewTableData);
        setPreviewVisible(true);
        
        message.success(`成功解析Excel文件，共找到 ${uniqueBarcodes.length} 个唯一条码`);
        
      } catch (error) {
        console.error('Excel解析失败:', error);
        message.error('Excel文件解析失败，请检查文件格式');
      } finally {
        setLoading(false);
      }
    };
    
    reader.onerror = () => {
      message.error('文件读取失败');
      setLoading(false);
    };
    
    reader.readAsArrayBuffer(file);
    
    // 阻止默认上传行为
    return false;
  };

  // 确认导入数据
  const handleConfirmImport = () => {
    if (onDataImported && typeof onDataImported === 'function') {
      onDataImported(barcodeData);
    }
    setPreviewVisible(false);
    message.success(`已导入 ${barcodeData.length} 个电芯条码`);
  };

  // 取消导入
  const handleCancelImport = () => {
    setPreviewVisible(false);
    setBarcodeData([]);
    setPreviewData([]);
  };

  // 预览表格列配置
  const previewColumns = [
    {
      title: '工作表',
      dataIndex: 'sheet',
      key: 'sheet',
      width: 120,
      render: (text) => <Tag color="blue">{text}</Tag>
    },
    {
      title: '行',
      dataIndex: 'row',
      key: 'row',
      width: 60,
      align: 'center'
    },
    {
      title: '列',
      dataIndex: 'column',
      key: 'column',
      width: 60,
      align: 'center'
    },
    {
      title: '条码数据',
      dataIndex: 'barcode',
      key: 'barcode',
      ellipsis: true,
      render: (text) => <code style={{ fontSize: '12px' }}>{text}</code>
    }
  ];

  const uploadProps = {
    accept: '.xlsx,.xls',
    beforeUpload: handleFileSelect,
    showUploadList: false,
    multiple: false
  };

  return (
    <>
      <Upload {...uploadProps}>
        <Button 
          type="primary" 
          icon={<FileExcelOutlined />}
          loading={loading}
          style={style}
        >
          {buttonText}
        </Button>
      </Upload>

      <Modal
        title="Excel数据预览"
        open={previewVisible}
        onOk={handleConfirmImport}
        onCancel={handleCancelImport}
        width={800}
        okText="确认导入"
        cancelText="取消"
        okButtonProps={{ 
          disabled: barcodeData.length === 0 
        }}
      >
        <div style={{ marginBottom: 16 }}>
          <p>
            <strong>解析结果：</strong>
            共找到 <Tag color="green">{barcodeData.length}</Tag> 个唯一的电芯条码
          </p>
          <p style={{ fontSize: '12px', color: '#666' }}>
            以下是从Excel文件中解析出的所有非空单元格数据：
          </p>
        </div>
        
        <Table
          columns={previewColumns}
          dataSource={previewData}
          pagination={{
            pageSize: 10,
            showSizeChanger: true,
            showQuickJumper: true,
            showTotal: (total) => `共 ${total} 条数据`
          }}
          size="small"
          scroll={{ y: 400 }}
        />
        
        <div style={{ marginTop: 16, padding: 12, backgroundColor: '#f5f5f5', borderRadius: 4 }}>
          <p style={{ margin: 0, fontSize: '12px', color: '#666' }}>
            <strong>提示：</strong>
            系统会自动提取Excel文件中所有工作表的所有非空单元格作为电芯条码，并自动去重。
            确认导入后，这些条码将传递给父组件进行后续处理。
          </p>
        </div>
      </Modal>
    </>
  );
};

export default ExcelImportButton; 