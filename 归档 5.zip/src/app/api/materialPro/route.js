// 基础 API 地址
const BASE_URL = 'http://10.22.161.62:8083';

/**
 * 处理 POST 请求，获取物料生产数据
 * @param {Request} request - 请求对象
 * @returns {Response} - 响应对象
 */
export async function POST(request) {
  try {
    // 解析请求体
    const body = await request.json();
    const { material_lot_code, operation_name } = body;

    // 验证必要参数
    if (!material_lot_code || !operation_name) {
      return Response.json({ error: '缺少必要参数' }, { status: 400 });
    }

    // 第一步：调用 coreBagCode 接口获取芯包码
    const coreBagCodeResponse = await fetch(`${BASE_URL}/api/5m1e/coreBagCode`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        material_lot_code,
        operation_name,
      }),
    });

    // 检查 coreBagCode 响应状态
    if (!coreBagCodeResponse.ok) {
      return Response.json(
        { error: `获取芯包码失败: ${coreBagCodeResponse.status}` },
        { status: coreBagCodeResponse.status }
      );
    }

    const coreBagCodeData = await coreBagCodeResponse.json();
    
    // 提取芯包码数组
    let coreBagCodes = [];
    if (coreBagCodeData && Array.isArray(coreBagCodeData)) {
      coreBagCodes = coreBagCodeData;
    } else if (coreBagCodeData && coreBagCodeData.core_bag_code) {
      // 如果返回的是单个芯包码
      coreBagCodes = [coreBagCodeData.core_bag_code];
    } else if (coreBagCodeData && Array.isArray(coreBagCodeData.data)) {
      coreBagCodes = coreBagCodeData.data;
    } else {
      // 尝试从响应中提取所有可能的芯包码字段
      const extractCoreBagCodes = (obj) => {
        const codes = [];
        if (typeof obj === 'object' && obj !== null) {
          Object.values(obj).forEach(value => {
            if (typeof value === 'string' && value.length > 0) {
              codes.push(value);
            } else if (Array.isArray(value)) {
              codes.push(...value);
            } else if (typeof value === 'object') {
              codes.push(...extractCoreBagCodes(value));
            }
          });
        }
        return codes;
      };
      coreBagCodes = extractCoreBagCodes(coreBagCodeData);
    }

    // 如果没有获取到芯包码，返回空结果
    if (!coreBagCodes.length) {
      return Response.json({ Material: [] });
    }

    // 第二步：使用每个芯包码调用 material-pro 接口
    const materialProPromises = coreBagCodes.map(async (coreBagCode) => {
      try {
        const response = await fetch(`${BASE_URL}/api/5m1e/material-pro`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            core_bag_code: coreBagCode,
          }),
        });

        if (!response.ok) {
          console.warn(`material-pro API 请求失败 (芯包码: ${coreBagCode}): ${response.status}`);
          return { Material: [] };
        }

        const data = await response.json();
        return data;
      } catch (error) {
        console.warn(`material-pro API 请求错误 (芯包码: ${coreBagCode}):`, error);
        return { Material: [] };
      }
    });

    // 等待所有请求完成
    const materialProResults = await Promise.all(materialProPromises);

    // 合并所有结果
    const allMaterials = [];
    materialProResults.forEach(result => {
      if (result && result.Material && Array.isArray(result.Material)) {
        allMaterials.push(...result.Material);
      }
    });

    // 返回合并后的结果
    return Response.json({
      Material: allMaterials,
      metadata: {
        coreBagCodesUsed: coreBagCodes,
        totalMaterials: allMaterials.length,
        requestsCount: coreBagCodes.length
      }
    });

  } catch (error) {
    console.error('处理 materialPro 请求失败:', error);
    return Response.json(
      { error: '服务器内部错误', message: error.message },
      { status: 500 }
    );
  }
} 