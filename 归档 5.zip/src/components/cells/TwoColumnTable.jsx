import React, { useState, useEffect } from 'react';
import { Table } from 'antd';
import { useSearchStore } from '../../store';
import MaterialTableNew from './MaterialTableNew';

/**
 * 获取工艺名称
 * @param {string} code - 工艺代码
 * @returns {string} - 工艺名称
 */
function getProcessName(code) {
  const processMap = {
    C021: "正极搅拌",
    C022: "陶瓷搅拌", 
    C023: "底涂搅拌",
    C030: "正极涂布",
    C040: "正极辊分",
    A020: "负极搅拌",
    A030: "负极涂布",
    A040: "负极辊分",
    S010: "切叠热压",
    E010: "X-Ray01",
    E020: "极耳预焊",
    E030: "极耳终焊",
    E040: "盖板&连接片焊接前",
    E050: "包PET膜",
    E060: "入壳预焊",
    E070: "盖板满焊",
    E080: "X-Ray02",
    E090: "前氦检",
    E100: "真空烘烤",
    E110: "一次注液",
    F010: "高温静置1",
    F020: "OCV0",
    F030: "拔化成钉",
    F040: "化成",
    F050: "入化成钉",
    F060: "高温静置2",
    F070: "OCV1",
    F080: "二次注液",
    F090: "密封钉焊接",
    F100: "后氦检",
    F110: "加拘束1",
    F120: "SOC调整",
    F130: "高温静置3",
    F140: "常温静置1",
    F150: "OCV2",
    F160: "常温静置2",
    F170: "OCV3",
    F180: "加拘束2",
    F190: "分容",
    F200: "常温静置3",
    F210: "OCV4",
    F220: "常温静置4",
    F230: "OCV5",
    F240: "常温静置5",
    F250: "OCV6",
    F260: "DCIR",
    F270: "常温静置6",
    Z100: "B芯包"
  };
  
  return processMap[code] || code;
}

const TwoColumnTable = ({ data = [], material_lot_code = '', excludeProcessName = '' }) => {
  const { material_lot_code: storeMaterialLotCode } = useSearchStore();

  // 统一的单元格背景色
  const cellBackgroundColor = '#f8fafc';

  // 定义主表格列 - 只包含工艺名称
  const columns = [
    {
      title: '工艺名称',
      dataIndex: 'title',
      key: 'title',
      width: 150,
      onCell: () => ({
        style: { 
          backgroundColor: cellBackgroundColor,
          padding: '8px',
          verticalAlign: 'top'
        }
      }),
      render: (text) => (
        <span className="font-medium text-gray-700">{text}</span>
      ),
    },
  ];

  // 原材料表格组件 - 专门处理原材料数据
  const MaterialTable = () => {
    const [materialData, setMaterialData] = useState({
      positive: null, // 正极浆料
      ceramic: null,  // 陶瓷浆料
      negative: null  // 负极浆料
    });
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    
    const effectiveMaterialLotCode = material_lot_code || storeMaterialLotCode;

    // 获取原材料数据
    const fetchMaterialData = async () => {
      if (!effectiveMaterialLotCode) {
        console.log('缺少 material_lot_code，跳过原材料API调用');
        return;
      }

      setLoading(true);
      setError(null);

      try {
        // 并行调用三种浆料的数据 - 全部使用 materialPro 接口
        const [positiveRes, ceramicRes, negativeRes] = await Promise.all([
          fetch('/api/materialPro', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              material_lot_code: effectiveMaterialLotCode,
              operation_name: 'C021' // 正极浆料
            }),
          }),
          fetch('/api/materialPro', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              material_lot_code: effectiveMaterialLotCode,
              operation_name: 'C022' // 陶瓷浆料
            }),
          }),
          fetch('/api/materialPro', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              material_lot_code: effectiveMaterialLotCode,
              operation_name: 'A020' // 负极浆料
            }),
          })
        ]);

        const [positiveData, ceramicData, negativeData] = await Promise.all([
          positiveRes.ok ? positiveRes.json() : { materialPro: [] },
          ceramicRes.ok ? ceramicRes.json() : { materialPro: [] },
          negativeRes.ok ? negativeRes.json() : { materialPro: [] }
        ]);

        setMaterialData({
          positive: positiveData.materialPro || [],
          ceramic: ceramicData.materialPro || [],
          negative: negativeData.materialPro || []
        });

      } catch (err) {
        setError(err.message);
        console.error('获取原材料数据失败:', err);
      } finally {
        setLoading(false);
      }
    };

    useEffect(() => {
      fetchMaterialData();
    }, [effectiveMaterialLotCode]);

    // 生成原材料表格列
    const generateMaterialColumns = () => {
      return [
        {
          title: '正极浆料',
          dataIndex: 'positive',
          key: 'positive',
          width: 200,
          render: (text) => text,
          onCell: () => ({
            style: { 
              backgroundColor: cellBackgroundColor,
              fontSize: '12px',
              padding: '8px',
              textAlign: 'center',
              fontWeight: 'bold'
            }
          }),
        },
        {
          title: '陶瓷浆料',
          dataIndex: 'ceramic',
          key: 'ceramic',
          width: 200,
          render: (text) => text,
          onCell: () => ({
            style: { 
              backgroundColor: cellBackgroundColor,
              fontSize: '12px',
              padding: '8px',
              textAlign: 'center',
              fontWeight: 'bold'
            }
          }),
        },
        {
          title: '负极浆料',
          dataIndex: 'negative',
          key: 'negative',
          width: 200,
          render: (text) => text,
          onCell: () => ({
            style: { 
              backgroundColor: cellBackgroundColor,
              fontSize: '12px',
              padding: '8px',
              textAlign: 'center',
              fontWeight: 'bold'
            }
          }),
        }
      ];
    };

    // 生成原材料数据源
    const generateMaterialDataSource = () => {
      if (loading) {
        return [
          { key: 'loading', positive: '正在加载...', ceramic: '正在加载...', negative: '正在加载...' }
        ];
      }

      if (error) {
        return [
          { key: 'error', positive: `加载失败: ${error}`, ceramic: `加载失败: ${error}`, negative: `加载失败: ${error}` }
        ];
      }

      // 找出最大数组长度来确定行数
      const maxLength = Math.max(
        materialData.positive?.length || 0,
        materialData.ceramic?.length || 0,
        materialData.negative?.length || 0,
        1 // 至少一行
      );

      const dataSource = [];
      for (let i = 0; i < maxLength; i++) {
        dataSource.push({
          key: `row_${i}`,
          positive: materialData.positive?.[i]?.material_lot_code || '暂无数据',
          ceramic: materialData.ceramic?.[i]?.material_lot_code || '暂无数据',
          negative: materialData.negative?.[i]?.material_lot_code || '暂无数据'
        });
      }

      return dataSource;
    };

    const materialColumns = generateMaterialColumns();
    const materialDataSource = generateMaterialDataSource();
    const tableWidth = 600; // 3列 * 200px

    return (
      <div style={{ width: `${tableWidth}px`, minWidth: `${tableWidth}px` }}>
        <Table
          columns={materialColumns}
          dataSource={materialDataSource}
          pagination={false}
          showHeader={true}
          size="small"
          bordered
          scroll={false}
          style={{ 
            tableLayout: 'fixed',
            width: `${tableWidth}px`
          }} 
          tableLayout="fixed"
        />
      </div>
    );
  };

  // 嵌套表格组件 - 包含条码和结果参数两个表格
  const NestedTable = ({ processName, title, excludeProcessName, codeName }) => {
    // 条码相关状态
    const [coreBagCodes, setCoreBagCodes] = useState([]);
    const [codeLoading, setCodeLoading] = useState(false);
    const [codeError, setCodeError] = useState(null);
    
    // 结果参数相关状态
    const [resultParams, setResultParams] = useState([]);
    const [paramLoading, setParamLoading] = useState(false);
    const [paramError, setParamError] = useState(null);
    
    const effectiveMaterialLotCode = material_lot_code || storeMaterialLotCode;

    // 排除工艺的条码数据
    const [excludeCoreBagCodes, setExcludeCoreBagCodes] = useState([]);

    // 获取排除工艺的芯包码数据
    const fetchExcludeCoreBagCodes = async () => {
      if (!effectiveMaterialLotCode || !excludeProcessName) {
        return;
      }

      try {
        const response = await fetch('/api/coreBagCode', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            material_lot_code: effectiveMaterialLotCode,
            operation_name: excludeProcessName,
          }),
        });

        if (response.ok) {
          const data = await response.json();
          setExcludeCoreBagCodes(data.coreBagCode || []);
        }
      } catch (err) {
        console.error('获取排除工艺芯包码失败:', err);
      }
    };

    // 获取芯包码数据
    const fetchCoreBagCodes = async () => {
      console.log('NestedTable fetchCoreBagCodes:', {
        material_lot_code: effectiveMaterialLotCode,
        processName,
        codeName,
        title
      });
      
      // 优先使用 codeName，如果没有则使用 processName
      const operationName = codeName || processName;
      
      if (!effectiveMaterialLotCode || !operationName) {
        console.log('缺少必要参数，跳过条码API调用');
        return;
      }

      setCodeLoading(true);
      setCodeError(null);

      try {
        const response = await fetch('/api/coreBagCode', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            material_lot_code: effectiveMaterialLotCode,
            operation_name: operationName,
          }),
        });

        if (!response.ok) {
          throw new Error(`条码请求失败: ${response.status}`);
        }

        const data = await response.json();
        console.log('条码API响应数据:', data);
        setCoreBagCodes(data.coreBagCode || []);
      } catch (err) {
        setCodeError(err.message);
        console.error('获取芯包码失败:', err);
      } finally {
        setCodeLoading(false);
      }
    };

    // 获取结果参数数据
    const fetchResultParamsData = async () => {
      console.log('NestedTable fetchResultParamsData:', {
        material_lot_code: effectiveMaterialLotCode,
        processName,
        title
      });

      if (!effectiveMaterialLotCode || !processName) {
        console.log('缺少必要参数，跳过结果参数API调用');
        return;
      }

      setParamLoading(true);
      setParamError(null);

      try {
        const response = await fetch('/api/resultParams', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            material_lot_code: effectiveMaterialLotCode,
            operation_name: processName,
          }),
        });

        if (!response.ok) {
          throw new Error(`结果参数请求失败: ${response.status}`);
        }

        const data = await response.json();
        console.log('结果参数API响应数据:', data);
        setResultParams(data.rawData || []);
      } catch (err) {
        setParamError(err.message);
        console.error('获取结果参数失败:', err);
      } finally {
        setParamLoading(false);
      }
    };

    useEffect(() => {
      fetchCoreBagCodes();
      fetchResultParamsData();
    }, [effectiveMaterialLotCode, processName, codeName]);

    // 生成条码表格列
    const generateCodeColumns = () => {
      const baseColumns = [
        {
          title: '追溯层级',
          dataIndex: 'level',
          key: 'level',
          width: 120,
          align: 'center',
          render: () => '追溯层级',
          onCell: () => ({
            style: { 
              backgroundColor: cellBackgroundColor,
              width: '120px !important',
              minWidth: '120px !important',
              maxWidth: '120px !important',
              boxSizing: 'border-box'
            }
          }),
        },
        {
          title: '工艺名称',
          dataIndex: 'title',
          key: 'title',
          width: 150,
          render: () => title,
          onCell: () => ({
            style: { 
              backgroundColor: cellBackgroundColor,
              width: '150px !important',
              minWidth: '150px !important',
              maxWidth: '150px !important',
              boxSizing: 'border-box'
            }
          }),
        },
        {
          title: '条码号',
          dataIndex: 'barcode',
          key: 'barcode',
          width: 120,
          render: () => '条码号',
          onCell: () => ({
            style: { 
              backgroundColor: cellBackgroundColor,
              width: '120px !important',
              minWidth: '120px !important',
              maxWidth: '120px !important',
              boxSizing: 'border-box'
            }
          }),
        },
      ];

      if (codeLoading) {
        baseColumns.push({
          title: '查询结果',
          dataIndex: 'loading',
          key: 'loading',
          width: 200,
          render: () => '正在加载...',
          onCell: () => ({
            style: { 
              backgroundColor: cellBackgroundColor,
              width: '200px !important',
              minWidth: '200px !important',
              maxWidth: '200px !important'
            }
          }),
        });
      } else if (codeError) {
        baseColumns.push({
          title: '查询结果',
          dataIndex: 'error',
          key: 'error',
          width: 300,
          render: () => codeError.includes('500') ? '暂无数据' : `加载失败: ${codeError}`,
          onCell: () => ({
            style: { 
              backgroundColor: cellBackgroundColor,
              color: '#ef4444',
              width: '300px !important',
              minWidth: '300px !important',
              maxWidth: '300px !important'
            }
          }),
        });
      } else if (coreBagCodes.length > 0) {
        coreBagCodes.forEach((code, index) => {
          baseColumns.push({
            title: `条码${index + 1}`,
            dataIndex: `code_${index}`,
            key: `code_${index}`,
            width: 200,
            render: () => code,
            onCell: () => ({
              style: { 
                backgroundColor: cellBackgroundColor,
                fontSize: '12px',
                whiteSpace: 'nowrap',
                width: '200px !important',
                minWidth: '200px !important',
                maxWidth: '200px !important',
                overflow: 'hidden',
                textOverflow: 'ellipsis',
                boxSizing: 'border-box'
              }
            }),
          });
        });
      } else {
        baseColumns.push({
          title: '查询结果',
          dataIndex: 'nodata',
          key: 'nodata',
          width: 200,
          render: () => '暂无数据',
          onCell: () => ({
            style: { 
              backgroundColor: cellBackgroundColor,
              color: '#6b7280',
              width: '200px !important',
              minWidth: '200px !important',
              maxWidth: '200px !important'
            }
          }),
        });
      }

      return baseColumns;
    };

    // 生成结果参数表格列
    const generateParamColumns = () => {
      const columns = [];
      
      if (paramLoading || paramError || resultParams.length === 0) {
        columns.push({
          title: '状态',
          dataIndex: 'status',
          key: 'status',
          width: 200,
          render: (text) => text,
          onCell: () => ({
            style: { 
              backgroundColor: cellBackgroundColor,
              width: '200px !important',
              minWidth: '200px !important',
              maxWidth: '200px !important',
              boxSizing: 'border-box'
            }
          }),
        });
      } else {
        resultParams.forEach((param, index) => {
          columns.push({
            title: `参数${index + 1}`,
            dataIndex: `param_${index}`,
            key: `param_${index}`,
            width: 180,
            render: (text) => text,
            onCell: () => ({
              style: { 
                backgroundColor: cellBackgroundColor,
                width: '180px !important',
                minWidth: '180px !important',
                maxWidth: '180px !important',
                fontSize: '12px',
                boxSizing: 'border-box'
              }
            }),
          });
        });
      }

      return columns;
    };

    // 条码表格数据
    const codeDataSource = [
      {
        key: '1',
        level: '追溯层级',
        title: title,
        barcode: '条码号',
        ...coreBagCodes.reduce((acc, code, index) => {
          acc[`code_${index}`] = code;
          return acc;
        }, {}),
      },
    ];

    // 结果参数表格数据
    const generateParamDataSource = () => {
      if (paramLoading) {
        return [
          { key: 'process', rowType: 'process', status: '正在加载...' },
          { key: 'paramType', rowType: 'paramType', status: '' },
          { key: 'columnName', rowType: 'columnName', status: '' },
          { key: 'result', rowType: 'result', status: '' }
        ];
      }

      if (paramError) {
        // 如果是500错误，显示"暂无数据"而不是错误信息
        const displayMessage = paramError.includes('500') ? '暂无数据' : `加载失败: ${paramError}`;
        return [
          { key: 'process', rowType: 'process', status: displayMessage },
          { key: 'paramType', rowType: 'paramType', status: '' },
          { key: 'columnName', rowType: 'columnName', status: '' },
          { key: 'result', rowType: 'result', status: '' }
        ];
      }

      if (resultParams.length === 0) {
        return [
          { key: 'process', rowType: 'process', status: '暂无数据' },
          { key: 'paramType', rowType: 'paramType', status: '' },
          { key: 'columnName', rowType: 'columnName', status: '' },
          { key: 'result', rowType: 'result', status: '' }
        ];
      }

      return [
        {
          key: 'process',
          rowType: 'process',
          ...resultParams.reduce((acc, param, index) => {
            acc[`param_${index}`] = getProcessName(processName);
            return acc;
          }, {})
        },
        {
          key: 'paramType', 
          rowType: 'paramType',
          ...resultParams.reduce((acc, param, index) => {
            acc[`param_${index}`] = '结果参数';
            return acc;
          }, {})
        },
        {
          key: 'columnName',
          rowType: 'columnName', 
          ...resultParams.reduce((acc, param, index) => {
            acc[`param_${index}`] = param.columns;
            return acc;
          }, {})
        },
        {
          key: 'result',
          rowType: 'result',
          ...resultParams.reduce((acc, param, index) => {
            acc[`param_${index}`] = param.rows;
            return acc;
          }, {})
        }
      ];
    };

    const paramDataSource = generateParamDataSource();
    const codeColumns = generateCodeColumns();
    const paramColumns = generateParamColumns();

    // 计算总宽度
    const codeTableWidth = 390 + (coreBagCodes.length * 200);
    const paramTableWidth = resultParams.length > 0 ? resultParams.length * 180 : 200;
    const totalWidth = Math.max(codeTableWidth, paramTableWidth);

    return (
      <div style={{ width: `${totalWidth}px`, minWidth: `${totalWidth}px` }}>
        {/* 条码表格 */}
        <div style={{ marginBottom: '16px' }}>
          <Table
            columns={codeColumns}
            dataSource={codeDataSource}
            pagination={false}
            showHeader={false}
            size="small"
            bordered
            scroll={false}
            style={{ 
              tableLayout: 'fixed',
              width: `${codeTableWidth}px`
            }} 
            tableLayout="fixed"
          />
        </div>

        {/* 结果参数表格 */}
        <div>
          <Table
            columns={paramColumns}
            dataSource={paramDataSource}
            pagination={false}
            showHeader={false}
            size="small"
            bordered
            scroll={false}
            style={{ 
              width: `${paramTableWidth}px`,
              tableLayout: 'fixed'
            }}
            tableLayout="fixed"
            components={{
              body: {
                cell: (props) => {
                  const { children, rowIndex, record, column, ...restProps } = props;
                  const isFirstColumn = column && (column.key === `param_0` || column.key === 'status');
                  
                  // 第1行工序：合并所有列
                  if (rowIndex === 0 && resultParams.length > 0) {
                    if (isFirstColumn) {
                      return (
                        <td 
                          {...restProps} 
                          colSpan={resultParams.length}
                          style={{
                            backgroundColor: '#fef3c7',
                            textAlign: 'center',
                            fontWeight: 'bold',
                            padding: '12px'
                          }}
                        >
                          {getProcessName(processName)}
                        </td>
                      );
                    }
                    return null;
                  }
                  
                  // 第2行参数类型：合并所有列
                  if (rowIndex === 1 && resultParams.length > 0) {
                    if (isFirstColumn) {
                      return (
                        <td 
                          {...restProps} 
                          colSpan={resultParams.length}
                          style={{
                            backgroundColor: '#e0e7ff',
                            textAlign: 'center',
                            fontWeight: 'bold',
                            padding: '12px'
                          }}
                        >
                          结果参数
                        </td>
                      );
                    }
                    return null;
                  }
                  
                  // 第3行采集项名称
                  if (rowIndex === 2) {
                    return (
                      <td 
                        {...restProps}
                        style={{
                          backgroundColor: '#dcfce7',
                          fontSize: '12px',
                          fontWeight: 'bold',
                          padding: '12px',
                          textAlign: 'center'
                        }}
                      >
                        {children}
                      </td>
                    );
                  }
                  
                  // 第4行数据结果
                  if (rowIndex === 3) {
                    return (
                      <td 
                        {...restProps}
                        style={{
                          backgroundColor: cellBackgroundColor,
                          fontSize: '12px',
                          padding: '12px',
                          textAlign: 'center'
                        }}
                      >
                        {children}
                      </td>
                    );
                  }
                  
                  return (
                    <td {...restProps} style={{ padding: '12px' }}>
                      {children}
                    </td>
                  );
                },
              },
            }}
          />
        </div>
      </div>
    );
  };

  // 转换数据格式
  const dataSource = data.map((row, index) => ({
    key: index,
    title: row.title,
    processName: row.content?.props?.processName,
    componentTitle: row.content?.props?.title,
    excludeProcessName: row.content?.props?.excludeProcessName,
    codeName: row.content?.props?.codeName,
  }));

  return (
    <div style={{ width: 'max-content', minWidth: '100%' }}>
      <div style={{ position: 'relative' }}>
        {/* 固定的第一列 - 绝对定位 */}
        <div 
          style={{
            position: 'absolute',
            left: 0,
            top: 0,
            width: '300px',
            backgroundColor: cellBackgroundColor,
            border: '1px solid #d1d5db',
            borderRight: '1px solid #d1d5db',
            zIndex: 10,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            minHeight: '100%',
            boxSizing: 'border-box'
          }}
          className="absolute-material-column"
        >
          <div className="font-bold text-gray-800 text-center px-2 break-words">
            {material_lot_code || '暂无批次号'}
          </div>
        </div>
        
        {/* 主表格部分 */}
        <div style={{ marginLeft: '300px', width: 'max-content' }}>
          <Table
            columns={columns}
            dataSource={dataSource}
            pagination={false}
            showHeader={false}
            size="small"
            bordered
            scroll={false}
            style={{ width: 'max-content' }}
            tableLayout="auto"
            rowClassName="hover:bg-gray-50"
            expandable={{
              expandedRowRender: (record) => (
                <div style={{ margin: 0, padding: 0, width: 'max-content' }}>
                  {/* 判断是否为原材料，使用不同的表格组件 */}
                  {record.processName === null && record.componentTitle === '原材料' ? (
                    <MaterialTableNew material_lot_code={material_lot_code} storeMaterialLotCode={storeMaterialLotCode} />
                  ) : (
                    <NestedTable 
                      processName={record.processName} 
                      title={record.componentTitle}
                      excludeProcessName={record.excludeProcessName || excludeProcessName}
                      codeName={record.codeName}
                    />
                  )}
                </div>
              ),
              rowExpandable: () => true,
              defaultExpandAllRows: true,
              expandIcon: () => null,
              expandRowByClick: false,
              showExpandColumn: false,
            }}
          />
        </div>
      </div>
      
      {/* CSS 样式 */}
      <style jsx>{`
        .absolute-material-column {
          height: 100% !important;
        }
        
        .ant-table-tbody > tr > td:first-child {
          border-left: none !important;
        }
      `}</style>
    </div>
  );
};

export default TwoColumnTable; 