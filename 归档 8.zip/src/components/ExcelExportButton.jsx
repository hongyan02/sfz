'use client';

import '@ant-design/v5-patch-for-react-19'; 
import React, { useState } from 'react';
import { Button, message, Progress } from 'antd';
import { DownloadOutlined } from '@ant-design/icons';
import * as XLSX from 'xlsx';

/**
 * Excel导出按钮组件 - 增强版，包含详细的API数据和可最小化进度条
 * 
 * 功能特性：
 * - 详细的导出进度显示
 * - 可最小化/最大化的进度模态框
 * - 最小化时允许用户继续操作页面
 * - 流畅的动画过渡效果
 * - 完整的错误处理和状态管理
 * - 支持新的API数据结构 {resultParameters: [{columns: "名称", rows: [数据数组]}]}
 * - 智能处理单行和多行数据：单行横向显示，多行按组展开
 * - 多行数据自动分组，每组使用不同背景色区分
 * - 丰富的Excel样式：标题、表头、数据行都有专门的样式设计
 * - 支持新的tableData数组结构：每个content包含多个工艺对象
 * - 分层显示：工艺分类（===）-> 具体工艺（---）-> 数据详情
 * - 自动处理codeName和processName的映射关系
 * - 单工作表模式：所有电芯数据合并到一个工作表中，便于查看和分析
 * - 电芯分隔：使用醒目的分隔标题和分隔线区分不同电芯的数据
 * - 多层次样式：电芯标题（橙红色）、工艺分类（蓝色）、具体工艺（紫色）
 * 
 * @param {Object} props
 * @param {Array} [props.exportData] - 要导出的数据数组，包含条码和对应的表格数据
 * @param {string} [props.filename] - 导出文件名
 * @param {Object} [props.style] - 按钮样式
 * @param {string} [props.buttonText] - 按钮文本
 * @param {number} [props.progressTop] - 进度条距离顶部的距离（px）
 */

const ExcelExportButton = ({ 
  exportData = [],
  filename = '电池数据管理',
  style = {},
  buttonText = '导出Excel',
  progressTop = 100
}) => {
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [isMinimized, setIsMinimized] = useState(false);

  // 获取原材料数据
  const fetchMaterialData = async (material_lot_code) => {
    try {
      const [positiveRes, ceramicRes, negativeRes] = await Promise.all([
        fetch('/api/materialPro', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            material_lot_code: material_lot_code,
            operation_name: 'C021' // 正极浆料
          }),
        }),
        fetch('/api/materialPro', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            material_lot_code: material_lot_code,
            operation_name: 'C022' // 陶瓷浆料
          }),
        }),
        fetch('/api/materialPro', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            material_lot_code: material_lot_code,
            operation_name: 'A020' // 负极浆料
          }),
        })
      ]);

      const [positiveData, ceramicData, negativeData] = await Promise.all([
        positiveRes.ok ? positiveRes.json() : { Material: [] },
        ceramicRes.ok ? ceramicRes.json() : { Material: [] },
        negativeRes.ok ? negativeRes.json() : { Material: [] }
      ]);

      return {
        positive: positiveData.Material || [],
        ceramic: ceramicData.Material || [],
        negative: negativeData.Material || []
      };
    } catch (error) {
      console.error('获取原材料数据失败:', error);
      return { positive: [], ceramic: [], negative: [] };
    }
  };

  // 获取条码数据
  const fetchCoreBagCodes = async (material_lot_code, operation_name) => {
    if (!operation_name) return [];
    
    try {
      const response = await fetch('/api/coreBagCode', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          material_lot_code: material_lot_code,
          operation_name: operation_name,
        }),
      });

      if (!response.ok) return [];
      const data = await response.json();
      return data.coreBagCode || [];
    } catch (error) {
      console.error('获取条码数据失败:', error);
      return [];
    }
  };

  // 获取结果参数数据
  const fetchResultParams = async (material_lot_code, operation_name) => {
    if (!operation_name) return [];
    
    try {
      const response = await fetch('/api/resultParams', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          material_lot_code: material_lot_code,
          operation_name: operation_name,
        }),
      });

      if (!response.ok) return [];
      const data = await response.json();
      return data.resultParameters || [];
    } catch (error) {
      console.error('获取结果参数数据失败:', error);
      return [];
    }
  };

  // 处理Excel导出 - 所有电芯数据合并到一个工作表
  const handleExport = async () => {
    if (exportData.length === 0) {
      message.warning('暂无数据可导出，请先导入电芯条码');
      return;
    }

    // 为电芯数据区域添加边框的辅助函数
    const addCellBorders = (worksheet, startRow, endRow, worksheetData) => {
      if (startRow <= 0 || endRow <= 0 || startRow > endRow) return;
      
      // 找出该区域的最大列数
      let maxCols = 0;
      for (let rowIndex = startRow - 1; rowIndex <= endRow - 1; rowIndex++) {
        if (worksheetData[rowIndex]) {
          maxCols = Math.max(maxCols, worksheetData[rowIndex].length);
        }
      }
      
      // 为整个电芯数据区域添加边框
      for (let rowIndex = startRow - 1; rowIndex <= endRow - 1; rowIndex++) {
        for (let colIndex = 0; colIndex < maxCols; colIndex++) {
          const cellAddress = XLSX.utils.encode_cell({ r: rowIndex, c: colIndex });
          if (!worksheet[cellAddress]) {
            worksheet[cellAddress] = { v: '' };
          }
          
          // 获取现有样式或创建新样式
          const existingStyle = worksheet[cellAddress].s || {};
          
          // 添加边框样式
          worksheet[cellAddress].s = {
            ...existingStyle,
            border: {
              top: { style: "medium", color: { rgb: "2563EB" } },    // 蓝色边框
              bottom: { style: "medium", color: { rgb: "2563EB" } },
              left: { style: "medium", color: { rgb: "2563EB" } },
              right: { style: "medium", color: { rgb: "2563EB" } }
            }
          };
          
          // 为边界单元格添加加粗边框
          if (rowIndex === startRow - 1) { // 顶部边框
            worksheet[cellAddress].s.border.top = { style: "thick", color: { rgb: "1D4ED8" } };
          }
          if (rowIndex === endRow - 1) { // 底部边框
            worksheet[cellAddress].s.border.bottom = { style: "thick", color: { rgb: "1D4ED8" } };
          }
          if (colIndex === 0) { // 左边框
            worksheet[cellAddress].s.border.left = { style: "thick", color: { rgb: "1D4ED8" } };
          }
          if (colIndex === maxCols - 1) { // 右边框
            worksheet[cellAddress].s.border.right = { style: "thick", color: { rgb: "1D4ED8" } };
          }
        }
      }
    };

    setLoading(true);
    setProgress(0);
    
    try {
      const workbook = XLSX.utils.book_new();
      const totalBarcodes = exportData.length;
      
      // 创建合并的工作表数据
      const worksheetData = [
        ['电池数据管理系统 - 所有电芯数据汇总'],
        ['导出时间', new Date().toLocaleString('zh-CN')],
        ['电芯总数', exportData.length],
        ['']
      ];
      
      // 处理每个电芯的数据
      for (let index = 0; index < exportData.length; index++) {
        const { barcode, tableData } = exportData[index];
        
        // 更新进度
        setProgress(Math.round((index / totalBarcodes) * 100));
        
        // 添加电芯分隔标题
        worksheetData.push([`████████ 电芯 ${index + 1}: ${barcode} ████████`]);
        worksheetData.push(['']);
        
        // 获取原材料数据
        const materialData = await fetchMaterialData(barcode);
        
        // 原材料部分
        worksheetData.push(['=== 原材料 ===']);
        
        // 准备横向数据结构
        const materialHeaders = []; // 原材料名称行（正极浆料、陶瓷浆料、负极浆料）
        const materialNames = [];   // 物料名称行
        const materialCodes = [];   // 物料批次行
        
        // 按顺序处理每种浆料类型的所有物料
        const materialTypes = [
          { name: '正极浆料', data: materialData.positive || [] },
          { name: '陶瓷浆料', data: materialData.ceramic || [] },
          { name: '负极浆料', data: materialData.negative || [] }
        ];
        
        materialTypes.forEach(type => {
          if (type.data.length === 0) {
            // 如果该类型没有数据，至少显示一列
            materialHeaders.push(type.name);
            materialNames.push('暂无数据');
            materialCodes.push('暂无数据');
          } else {
            // 为该类型的每个物料添加一列
            type.data.forEach(material => {
              materialHeaders.push(type.name);
              materialNames.push(material.MATERIAL_NAME || '暂无数据');
              materialCodes.push(material.MATERIAL_LOT_CODE || '暂无数据');
            });
          }
        });
        
        // 添加到工作表数据
        worksheetData.push(materialHeaders); // 第一行：正极浆料、陶瓷浆料、负极浆料...
        worksheetData.push(materialNames);   // 第二行：物料名称
        worksheetData.push(materialCodes);   // 第三行：物料批次
        
        worksheetData.push(['']); // 空行
        
        // 处理其他工艺流程 - 适配新的数组数据结构，横向平行显示
        for (const process of tableData) {
          // 跳过原材料分类，避免重复显示
          if (process.title === '原材料') {
            continue;
          }
          
          if (process.content && Array.isArray(process.content)) {
            // 添加工艺分类标题
            worksheetData.push([`=== ${process.title} ===`]);
            
            // 并行获取该分类下所有工艺的数据
            const processPromises = process.content.map(async (item) => {
              if (item.processName) {
                const processName = item.processName;
                const processTitle = item.title;
                const codeName = item.codeName;
                
                // 获取条码数据和结果参数
                const [coreBagCodes, resultParams] = await Promise.all([
                  fetchCoreBagCodes(barcode, codeName || processName),
                  fetchResultParams(barcode, processName)
                ]);
                
                return {
                  processTitle,
                  coreBagCodes,
                  resultParams
                };
              }
              return null;
            });
            
            // 等待所有工艺数据获取完成
            const processResults = await Promise.all(processPromises);
            const validResults = processResults.filter(result => result !== null);
            
            if (validResults.length > 0) {
              // 创建工艺标题行（横向显示所有工艺名称）
              const processTitleRow = ['工艺名称'];
              validResults.forEach(result => {
                processTitleRow.push(result.processTitle);
              });
              worksheetData.push(processTitleRow);
              
              // 处理条码数据（横向显示）
              const maxCoreBagCodes = Math.max(...validResults.map(result => result.coreBagCodes.length));
              if (maxCoreBagCodes > 0) {
                worksheetData.push(['']); // 空行分隔
                worksheetData.push(['条码数据']);
                
                // 为每个条码位置创建一行
                for (let codeIndex = 0; codeIndex < maxCoreBagCodes; codeIndex++) {
                  const codeRow = [`条码${codeIndex + 1}`];
                  validResults.forEach(result => {
                    const code = result.coreBagCodes[codeIndex];
                    codeRow.push(code || '');
                  });
                  worksheetData.push(codeRow);
                }
              }
              
              // 处理结果参数（横向显示）
              worksheetData.push(['']); // 空行分隔
              worksheetData.push(['结果参数']);
              
              // 找出所有工艺中最大的参数数量和行数
              let maxParamCount = 0;
              let maxRowCount = 0;
              
              validResults.forEach(result => {
                if (result.resultParams.length > 0) {
                  maxParamCount = Math.max(maxParamCount, result.resultParams.length);
                  const maxRows = Math.max(...result.resultParams.map(param => param.rows ? param.rows.length : 0));
                  maxRowCount = Math.max(maxRowCount, maxRows);
                }
              });
              
              if (maxParamCount > 0) {
                // 创建参数名称表头
                const paramHeaderRow = ['参数名称'];
                validResults.forEach(result => {
                  if (result.resultParams.length > 0) {
                    result.resultParams.forEach(param => {
                      paramHeaderRow.push(`${result.processTitle}-${param.columns || '暂无数据'}`);
                    });
                  } else {
                    paramHeaderRow.push(`${result.processTitle}-暂无数据`);
                  }
                });
                worksheetData.push(paramHeaderRow);
                
                // 处理数据行
                if (maxRowCount <= 1) {
                  // 单行数据：直接横向显示
                  const dataRow = ['数据值'];
                  validResults.forEach(result => {
                    if (result.resultParams.length > 0) {
                      result.resultParams.forEach(param => {
                        const value = param.rows && param.rows[0] ? param.rows[0] : '暂无数据';
                        dataRow.push(value);
                      });
                    } else {
                      dataRow.push('暂无数据');
                    }
                  });
                  worksheetData.push(dataRow);
                } else {
                  // 多行数据：按组展开
                  for (let rowIndex = 0; rowIndex < maxRowCount; rowIndex++) {
                    const dataRow = [`第${rowIndex + 1}组`];
                    validResults.forEach(result => {
                      if (result.resultParams.length > 0) {
                        result.resultParams.forEach(param => {
                          const value = param.rows && param.rows[rowIndex] !== undefined ? param.rows[rowIndex] : '';
                          dataRow.push(value);
                        });
                      } else {
                        dataRow.push('');
                      }
                    });
                    worksheetData.push(dataRow);
                  }
                }
              }
            }
            
            worksheetData.push(['']); // 分类间空行
          }
        }
        
        // 电芯间分隔
        worksheetData.push(['']);
        worksheetData.push(['------------------------------------------------------------------------------------------------------------------------------------------------------------------------------']);
        worksheetData.push(['']);
      }
      
      // 创建工作表
      const worksheet = XLSX.utils.aoa_to_sheet(worksheetData);
      
      // 设置列宽
      const maxCols = Math.max(...worksheetData.map(row => row.length));
      worksheet['!cols'] = Array(maxCols).fill(0).map(() => ({ width: 20 }));
      
      // 用于跟踪电芯数据区域的变量
      let currentCellIndex = 0; // 用于跟踪当前电芯的数据区域
      let cellStartRow = -1; // 记录每个电芯数据开始的行
      let cellEndRow = -1; // 记录每个电芯数据结束的行
      
      // 处理最后一个电芯的边框（如果存在）
      if (cellStartRow > 0 && exportData.length > 0) {
        // 最后一个电芯的结束行是倒数第三行（去掉最后的空行和分隔线）
        const lastCellEndRow = worksheetData.length - 3;
        if (lastCellEndRow >= cellStartRow) {
          addCellBorders(worksheet, cellStartRow, lastCellEndRow, worksheetData);
        }
      }
      
      // 设置标题样式
      const titleStyle = {
        font: { 
          bold: true, 
          size: 14,
          color: { rgb: "FFFFFF" }
        },
        fill: { 
          fgColor: { rgb: "4A90E2" } // 柔和的蓝色背景
        },
        alignment: { 
          horizontal: "center", 
          vertical: "center" 
        },
        border: {
          top: { style: "thin", color: { rgb: "000000" } },
          bottom: { style: "thin", color: { rgb: "000000" } },
          left: { style: "thin", color: { rgb: "000000" } },
          right: { style: "thin", color: { rgb: "000000" } }
        }
      };
      
      // 设置子标题样式（条码数据、结果参数等）
      const subTitleStyle = {
        font: { 
          bold: true, 
          size: 12,
          color: { rgb: "333333" }
        },
        fill: { 
          fgColor: { rgb: "E8F4FD" } // 更浅的蓝色背景
        },
        alignment: { 
          horizontal: "left", 
          vertical: "center" 
        }
      };
      
      // 设置基本信息样式
      const infoStyle = {
        font: { 
          bold: true, 
          size: 11,
          color: { rgb: "2C3E50" }
        },
        fill: { 
          fgColor: { rgb: "ECF0F1" } // 浅灰色背景
        }
      };
      
      // 应用样式到标题行
      let currentRow = 0;
      
      for (const row of worksheetData) {
        currentRow++;
        
        // 检查是否是电芯分隔标题行（包含 ████████ 的行）
        if (row[0] && typeof row[0] === 'string' && row[0].includes('████████')) {
          // 如果之前有电芯数据，为其添加底部边框
          if (cellStartRow > 0 && cellEndRow > 0) {
            addCellBorders(worksheet, cellStartRow, cellEndRow, worksheetData);
          }
          
          // 记录新电芯数据的开始位置（下一行开始）
          cellStartRow = currentRow + 1;
          currentCellIndex++;
          
          const cellAddress = XLSX.utils.encode_cell({ r: currentRow - 1, c: 0 });
          if (!worksheet[cellAddress]) worksheet[cellAddress] = { v: row[0] };
          worksheet[cellAddress].s = {
            font: { 
              bold: true, 
              size: 16,
              color: { rgb: "FFFFFF" }
            },
            fill: { 
              fgColor: { rgb: "FF6B35" } // 橙红色背景
            },
            alignment: { 
              horizontal: "center", 
              vertical: "center" 
            },
            border: {
              top: { style: "thick", color: { rgb: "000000" } },
              bottom: { style: "thick", color: { rgb: "000000" } },
              left: { style: "thick", color: { rgb: "000000" } },
              right: { style: "thick", color: { rgb: "000000" } }
            }
          };
        }
        
        // 检查是否是电芯分隔线（包含 ▼ 的行）
        if (row[0] && typeof row[0] === 'string' && row[0].includes('▼')) {
          // 记录当前电芯数据的结束位置（上一行结束）
          cellEndRow = currentRow - 2;
          
          const cellAddress = XLSX.utils.encode_cell({ r: currentRow - 1, c: 0 });
          if (!worksheet[cellAddress]) worksheet[cellAddress] = { v: row[0] };
          worksheet[cellAddress].s = {
            font: { 
              bold: true, 
              size: 14,
              color: { rgb: "666666" }
            },
            fill: { 
              fgColor: { rgb: "F5F5F5" } // 浅灰色背景
            },
            alignment: { 
              horizontal: "center", 
              vertical: "center" 
            }
          };
        }
        
        // 检查是否是子工艺标题行（包含 --- 的行）
        if (row[0] && typeof row[0] === 'string' && row[0].includes('---')) {
          const cellAddress = XLSX.utils.encode_cell({ r: currentRow - 1, c: 0 });
          if (!worksheet[cellAddress]) worksheet[cellAddress] = { v: row[0] };
          worksheet[cellAddress].s = {
            font: { 
              bold: true, 
              size: 12,
              color: { rgb: "FFFFFF" }
            },
            fill: { 
              fgColor: { rgb: "7C3AED" } // 紫色背景
            },
            alignment: { 
              horizontal: "center", 
              vertical: "center" 
            },
            border: {
              top: { style: "thin", color: { rgb: "000000" } },
              bottom: { style: "thin", color: { rgb: "000000" } },
              left: { style: "thin", color: { rgb: "000000" } },
              right: { style: "thin", color: { rgb: "000000" } }
            }
          };
        }
        
        // 检查是否是主标题行（包含 === 的行）
        if (row[0] && typeof row[0] === 'string' && row[0].includes('===')) {
          const cellAddress = XLSX.utils.encode_cell({ r: currentRow - 1, c: 0 });
          if (!worksheet[cellAddress]) worksheet[cellAddress] = { v: row[0] };
          worksheet[cellAddress].s = titleStyle;
        }
        
        // 检查是否是子标题行（条码数据、结果参数）
        if (row[0] && (row[0] === '条码数据' || row[0] === '结果参数')) {
          const cellAddress = XLSX.utils.encode_cell({ r: currentRow - 1, c: 0 });
          if (!worksheet[cellAddress]) worksheet[cellAddress] = { v: row[0] };
          worksheet[cellAddress].s = subTitleStyle;
        }
        
        // 检查是否是数据组表头行（包含"数据组"的行）
        if (row[0] && row[0] === '数据组') {
          // 为整行设置表头样式
          for (let colIndex = 0; colIndex < row.length; colIndex++) {
            const cellAddress = XLSX.utils.encode_cell({ r: currentRow - 1, c: colIndex });
            if (!worksheet[cellAddress]) worksheet[cellAddress] = { v: row[colIndex] };
            worksheet[cellAddress].s = {
              font: { 
                bold: true, 
                size: 11,
                color: { rgb: "FFFFFF" }
              },
              fill: { 
                fgColor: { rgb: "52C41A" } // 绿色背景
              },
              alignment: { 
                horizontal: "center", 
                vertical: "center" 
              },
              border: {
                top: { style: "thin", color: { rgb: "000000" } },
                bottom: { style: "thin", color: { rgb: "000000" } },
                left: { style: "thin", color: { rgb: "000000" } },
                right: { style: "thin", color: { rgb: "000000" } }
              }
            };
          }
        }
        
        // 检查是否是数据组行（以"第X组"开头的行）
        if (row[0] && typeof row[0] === 'string' && row[0].startsWith('第') && row[0].includes('组')) {
          // 提取组号
          const groupMatch = row[0].match(/第(\d+)组/);
          const groupIndex = groupMatch ? parseInt(groupMatch[1]) - 1 : 0;
          
          // 定义组颜色
          const groupColors = ['#F6FFED', '#FFF7E6', '#E6F7FF', '#FFF1F0', '#F9F0FF'];
          const groupColor = groupColors[groupIndex % groupColors.length];
          
          // 为整行设置样式
          for (let colIndex = 0; colIndex < row.length; colIndex++) {
            const cellAddress = XLSX.utils.encode_cell({ r: currentRow - 1, c: colIndex });
            if (!worksheet[cellAddress]) worksheet[cellAddress] = { v: row[colIndex] };
            worksheet[cellAddress].s = {
              font: { 
                size: 10,
                color: { rgb: "333333" }
              },
              fill: { 
                fgColor: { rgb: groupColor.replace('#', '') }
              },
              alignment: { 
                horizontal: "center", 
                vertical: "center" 
              },
              border: {
                top: { style: "thin", color: { rgb: "CCCCCC" } },
                bottom: { style: "thin", color: { rgb: "CCCCCC" } },
                left: { style: "thin", color: { rgb: "CCCCCC" } },
                right: { style: "thin", color: { rgb: "CCCCCC" } }
              }
            };
          }
        }
        
        // 检查是否是基本信息行（电芯条码、导出时间）
        if (row[0] && (row[0] === '电芯条码' || row[0] === '导出时间')) {
          const cellAddress = XLSX.utils.encode_cell({ r: currentRow - 1, c: 0 });
          if (!worksheet[cellAddress]) worksheet[cellAddress] = { v: row[0] };
          worksheet[cellAddress].s = infoStyle;
        }
      }
      
      // 工作表名称
      const sheetName = '所有电芯数据汇总';
      XLSX.utils.book_append_sheet(workbook, worksheet, sheetName);
      
      // 生成文件名
      const timestamp = new Date().toISOString().split('T')[0];
      const finalFilename = `${filename}_所有电芯数据汇总_${timestamp}.xlsx`;
      
      // 导出文件
      XLSX.writeFile(workbook, finalFilename);
      
      setProgress(100);
      message.success(`Excel文件导出成功！包含${exportData.length}个电芯的详细数据`);
      
    } catch (error) {
      console.error('Excel导出失败:', error);
      message.error('Excel导出失败，请重试');
    } finally {
      setLoading(false);
      setIsMinimized(false); // 重置最小化状态
      setTimeout(() => setProgress(0), 2000); // 2秒后重置进度
    }
  };

  return (
    <>
      {/* CSS动画样式 */}
      <style jsx>{`
        @keyframes slideInFromBottom {
          from {
            transform: translateY(100%);
            opacity: 0;
          }
          to {
            transform: translateY(0);
            opacity: 1;
          }
        }
        
        @keyframes slideInFromTop {
          from {
            transform: translate(-50%, -100%);
            opacity: 0;
          }
          to {
            transform: translate(-50%, 0);
            opacity: 1;
          }
        }
      `}</style>
      
      <Button 
        type="default" 
        icon={<DownloadOutlined />}
        loading={loading}
        onClick={handleExport}
        style={style}
        disabled={exportData.length === 0}
      >
        {buttonText}
      </Button>
      
      {/* 全局进度条 - 可最小化/最大化 */}
      {loading && !isMinimized && (
        <div style={{ 
          position: 'fixed', 
          top: `${progressTop}px`, // 可配置的进度条位置
          left: '50%',
          transform: 'translateX(-50%)',
          width: '70%', // 更宽的进度条
          maxWidth: '800px',
          minWidth: '500px',
          zIndex: 9999,
          backgroundColor: 'rgba(255, 255, 255, 0.98)',
          padding: '24px 32px',
          borderRadius: '16px',
          boxShadow: '0 8px 32px rgba(0, 0, 0, 0.12), 0 2px 8px rgba(0, 0, 0, 0.08)',
          border: '1px solid #e5e7eb',
          backdropFilter: 'blur(8px)',
          transition: 'all 0.3s ease-in-out',
          animation: 'slideInFromTop 0.3s ease-out'
        }}>
          {/* 标题栏 - 包含最小化按钮 */}
          <div style={{ 
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            marginBottom: '16px'
          }}>
            <div style={{ 
              fontSize: '16px',
              fontWeight: '600',
              color: '#1f2937',
              display: 'flex',
              alignItems: 'center',
              gap: '8px'
            }}>
              <DownloadOutlined style={{ color: '#3b82f6' }} />
              正在导出Excel文件
            </div>
            
            {/* 最小化按钮 */}
            <button
              onClick={() => setIsMinimized(true)}
              style={{
                background: 'none',
                border: 'none',
                cursor: 'pointer',
                padding: '4px 8px',
                borderRadius: '6px',
                color: '#6b7280',
                fontSize: '14px',
                transition: 'all 0.2s ease',
                display: 'flex',
                alignItems: 'center',
                gap: '4px'
              }}
              onMouseEnter={(e) => {
                e.target.style.backgroundColor = '#f3f4f6';
                e.target.style.color = '#374151';
              }}
              onMouseLeave={(e) => {
                e.target.style.backgroundColor = 'transparent';
                e.target.style.color = '#6b7280';
              }}
              title="最小化"
            >
              <span style={{ fontSize: '12px' }}>—</span>
              最小化
            </button>
          </div>
          
          <Progress 
            percent={progress} 
            size="default"
            format={(percent) => (
              <span style={{ 
                fontSize: '14px', 
                fontWeight: '600',
                color: '#1f2937'
              }}>
                {percent}%
              </span>
            )}
            strokeColor={{
              '0%': '#3b82f6',
              '30%': '#06b6d4', 
              '70%': '#10b981',
              '100%': '#059669'
            }}
            trailColor="#f1f5f9"
            style={{
              fontSize: '16px'
            }}
          />
          
          <div style={{ 
            textAlign: 'center', 
            marginTop: '12px',
            fontSize: '13px',
            color: '#6b7280',
            fontWeight: '500'
          }}>
            正在处理第 {Math.ceil((progress / 100) * exportData.length)} / {exportData.length} 个电芯数据
          </div>
          
          {/* 添加一个小的提示文本 */}
          <div style={{ 
            textAlign: 'center', 
            marginTop: '8px',
            fontSize: '11px',
            color: '#9ca3af',
            fontStyle: 'italic'
          }}>
            请耐心等待，正在生成详细数据报告...
          </div>
        </div>
      )}
      
                {/* 最小化状态 - 右下角小窗口 */}
      {loading && isMinimized && (
        <div 
          style={{
            position: 'fixed',
            bottom: '24px',
            right: '24px',
            width: '320px',
            zIndex: 9999,
            backgroundColor: 'rgba(255, 255, 255, 0.98)',
            padding: '16px 20px',
            borderRadius: '12px',
            boxShadow: '0 4px 20px rgba(0, 0, 0, 0.15), 0 1px 4px rgba(0, 0, 0, 0.1)',
            border: '1px solid #e5e7eb',
            backdropFilter: 'blur(8px)',
            transition: 'all 0.3s ease-in-out',
            animation: 'slideInFromBottom 0.3s ease-out',
            cursor: 'default'
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.transform = 'translateY(-2px)';
            e.currentTarget.style.boxShadow = '0 6px 25px rgba(0, 0, 0, 0.18), 0 2px 6px rgba(0, 0, 0, 0.12)';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.transform = 'translateY(0)';
            e.currentTarget.style.boxShadow = '0 4px 20px rgba(0, 0, 0, 0.15), 0 1px 4px rgba(0, 0, 0, 0.1)';
          }}
        >
          {/* 最小化标题栏 */}
          <div style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            marginBottom: '12px'
          }}>
            <div style={{
              fontSize: '14px',
              fontWeight: '600',
              color: '#1f2937',
              display: 'flex',
              alignItems: 'center',
              gap: '6px'
            }}>
              <DownloadOutlined style={{ color: '#3b82f6', fontSize: '12px' }} />
              导出进度
            </div>
            
            {/* 最大化按钮 */}
            <button
              onClick={() => setIsMinimized(false)}
              style={{
                background: 'none',
                border: 'none',
                cursor: 'pointer',
                padding: '4px 8px',
                borderRadius: '6px',
                color: '#6b7280',
                fontSize: '12px',
                transition: 'all 0.2s ease',
                display: 'flex',
                alignItems: 'center',
                gap: '4px'
              }}
              onMouseEnter={(e) => {
                e.target.style.backgroundColor = '#f3f4f6';
                e.target.style.color = '#374151';
              }}
              onMouseLeave={(e) => {
                e.target.style.backgroundColor = 'transparent';
                e.target.style.color = '#6b7280';
              }}
              title="展开"
            >
              <span style={{ fontSize: '10px' }}>□</span>
              展开
            </button>
          </div>
          
          {/* 紧凑的进度条 */}
          <Progress 
            percent={progress} 
            size="small"
            format={(percent) => (
              <span style={{ 
                fontSize: '12px', 
                fontWeight: '600',
                color: '#1f2937'
              }}>
                {percent}%
              </span>
            )}
            strokeColor={{
              '0%': '#3b82f6',
              '30%': '#06b6d4', 
              '70%': '#10b981',
              '100%': '#059669'
            }}
            trailColor="#f1f5f9"
          />
          
          {/* 简化的状态信息 */}
          <div style={{
            textAlign: 'center',
            marginTop: '8px',
            fontSize: '11px',
            color: '#6b7280'
          }}>
            {Math.ceil((progress / 100) * exportData.length)} / {exportData.length} 个电芯
          </div>
        </div>
      )}
      
      {/* 遮罩层 - 只在展开状态时显示，防止用户误操作 */}
      {loading && !isMinimized && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: 'rgba(0, 0, 0, 0.4)',
          zIndex: 9998,
          backdropFilter: 'blur(4px)',
          transition: 'all 0.3s ease-in-out'
        }} />
      )}
    </>
  );
};

export default ExcelExportButton; 