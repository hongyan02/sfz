/**
 * 处理结果参数请求
 */

/**
 * 处理 POST 请求，获取结果参数数据
 * @param {Request} request - 请求对象
 * @returns {Response} - 响应对象
 */
export async function POST(request) {
  try {
    // 解析请求体
    const body = await request.json();
    const { material_lot_code, operation_name } = body;

    // 验证必要参数
    if (!material_lot_code || !operation_name) {
      return Response.json({ error: '缺少必要参数' }, { status: 400 });
    }

    // 调用外部 API
    const apiUrl = 'http://10.22.161.62:8083/api/5m1e/result-params';
    
    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        material_lot_code,
        operation_name,
      }),
      // 如果外部 API 需要较长时间响应，设置较长的超时时间
      signal: AbortSignal.timeout(10000), // 10秒超时
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('API 请求失败:', response.status, errorText);
      return Response.json(
        { error: `API 请求失败: ${response.status}`, details: errorText },
        { status: response.status }
      );
    }

    // 获取 API 响应数据
    const data = await response.json();

    // 转换数据格式，将 resultParameters 转换为更易于处理的格式
    const formattedData = formatResultParameters(data.resultParameters || []);

    // 返回响应数据
    return Response.json(formattedData);
  } catch (error) {
    console.error('处理请求失败:', error);
    return Response.json(
      { error: '服务器内部错误', message: error.message },
      { status: 500 }
    );
  }
}

/**
 * 格式化结果参数数据
 * @param {Array} resultParameters - 原始结果参数数据
 * @returns {Object} - 格式化后的数据
 */
function formatResultParameters(resultParameters) {
  // 将数据转换为更易于前端处理的格式
  // 这里可以根据实际需求进行调整
  const items = resultParameters.map(item => ({
    name: item.columns,
    value: item.rows
  }));

  return {
    items,
    rawData: resultParameters // 保留原始数据，以防需要
  };
} 