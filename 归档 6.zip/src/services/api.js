/**
 * API 服务层
 * 提供与后端 API 交互的方法
 */

/**
 * 获取芯包码数据
 * @param {string} material_lot_code - 电芯条码
 * @param {string} operation_name - 工艺代码
 * @returns {Promise<{coreBagCode: string[]}>} - 芯包码数据
 */
export const fetchCoreBagCode = async (material_lot_code, operation_name) => {
  try {
    // 使用 Next.js API 路由
    const response = await fetch('/api/coreBagCode', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        material_lot_code,
        operation_name,
      }),
    });

    if (!response.ok) {
      throw new Error(`API 请求失败: ${response.status}`);
    }

    return await response.json();
  } catch (error) {
    console.error('获取芯包码数据失败:', error);
    // 返回空数据，避免前端报错
    return { coreBagCode: [] };
  }
};

/**
 * 获取工艺流程数据
 * @param {string} processName - 工艺流程代码
 * @param {string} material_lot_code - 电芯条码
 * @returns {Promise<Array>} - 工艺流程数据
 */
export async function fetchProcessData(processName, material_lot_code) {
  try {
    // 调用模拟 API
    const response = await fetch('/api/process-data', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        material_lot_code,
        operation_name: processName,
      }),
    });

    if (!response.ok) {
      throw new Error(`API 请求失败: ${response.status}`);
    }

    const data = await response.json();
    return data.items || [];
  } catch (error) {
    console.error('获取工艺流程数据失败:', error);
    throw error;
  }
}

/**
 * 获取结果参数数据
 * @param {string} processName - 工艺流程代码
 * @param {string} material_lot_code - 电芯条码
 * @returns {Promise<Object>} - 结果参数数据
 */
export async function fetchResultParams(processName, material_lot_code) {
  try {
    // 调用内部 API 路由
    const response = await fetch('/api/resultParams', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        material_lot_code,
        operation_name: processName,
      }),
    });

    if (!response.ok) {
      throw new Error(`API 请求失败: ${response.status}`);
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error('获取结果参数数据失败:', error);
    throw error;
  }
}

/**
 * 获取物料终点数据
 * @param {string} material_lot_code - 电芯条码
 * @param {string} [workcell_id] - 工作单元ID（可选）
 * @returns {Promise<Object>} - 物料终点数据
 */
export async function fetchMaterialEnd(material_lot_code, workcell_id = '') {
  try {
    // 调用内部 API 路由
    const response = await fetch('/api/materialEnd', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        material_lot_code,
        workcell_id,
      }),
    });

    if (!response.ok) {
      throw new Error(`API 请求失败: ${response.status}`);
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error('获取物料终点数据失败:', error);
    throw error;
  }
}

/**
 * 获取物料生产数据（连环调用）
 * 先调用 coreBagCode 接口获取芯包码，再调用 material-pro 接口获取物料数据
 * @param {string} material_lot_code - 电芯条码
 * @param {string} operation_name - 工艺代码
 * @returns {Promise<Object>} - 物料生产数据
 */
export async function fetchMaterialPro(material_lot_code, operation_name) {
  try {
    // 调用内部 API 路由
    const response = await fetch('/api/materialPro', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        material_lot_code,
        operation_name,
      }),
    });

    if (!response.ok) {
      throw new Error(`API 请求失败: ${response.status}`);
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error('获取物料生产数据失败:', error);
    throw error;
  }
}
