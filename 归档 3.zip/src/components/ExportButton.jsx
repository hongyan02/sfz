'use client';

import React, { useState } from 'react';
import { Button, message } from 'antd';
import { DownloadOutlined } from '@ant-design/icons';

/**
 * Excel导出按钮组件
 * @param {Object} props
 * @param {string} [props.filename] - 导出文件名
 * @param {Object} [props.style] - 按钮样式
 * @param {string} [props.targetId] - 要导出的元素ID，默认导出整个页面
 * @param {Array} [props.customData] - 自定义导出数据
 */
const ExportButton = ({ 
  filename = '电池生产线监控数据', 
  style = {},
  targetId = null,
  customData = null
}) => {
  const [loading, setLoading] = useState(false);

  const handleExport = async () => {
    setLoading(true);
    
    try {
      // 动态导入xlsx库，处理不同的导入方式
      let XLSX;
      try {
        const xlsxModule = await import('xlsx');
        XLSX = xlsxModule.default || xlsxModule;
        
        // 确保XLSX对象有utils属性
        if (!XLSX || !XLSX.utils) {
          throw new Error('XLSX库导入失败，缺少utils模块');
        }
      } catch (importError) {
        console.error('导入xlsx库失败:', importError);
        message.error('请先安装依赖：npm install xlsx');
        return;
      }

      let workbook;

      if (customData && Array.isArray(customData)) {
        // 使用自定义数据
        workbook = createWorkbookFromCustomData(XLSX, customData);
      } else {
        // 从页面提取数据
        const element = targetId ? document.getElementById(targetId) : document.body;
        
        if (!element) {
          message.error('未找到要导出的内容');
          return;
        }

        workbook = await createWorkbookFromElement(XLSX, element);
      }

      // 导出Excel文件
      const fileName = `${filename}_${new Date().toISOString().split('T')[0]}.xlsx`;
      XLSX.writeFile(workbook, fileName);

      message.success('Excel导出成功！');

    } catch (error) {
      console.error('Excel导出失败:', error);
      message.error(`Excel导出失败: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  // 从自定义数据创建工作簿
  const createWorkbookFromCustomData = (XLSX, data) => {
    const workbook = XLSX.utils.book_new();

    data.forEach((sheetData, index) => {
      const worksheet = XLSX.utils.json_to_sheet(sheetData.data || []);
      const sheetName = sheetData.name || `Sheet${index + 1}`;
      XLSX.utils.book_append_sheet(workbook, worksheet, sheetName);
    });

    return workbook;
  };

  // 从页面元素创建工作簿
  const createWorkbookFromElement = async (XLSX, element) => {
    console.log('开始创建工作簿，XLSX对象:', XLSX);
    console.log('XLSX.utils是否存在:', !!XLSX.utils);
    
    const workbook = XLSX.utils.book_new();

    // 查找页面中的所有表格
    const tables = element.querySelectorAll('table');
    console.log('找到表格数量:', tables.length);
    
    if (tables.length > 0) {
      // 导出表格数据
      tables.forEach((table, index) => {
        try {
          console.log(`处理第${index + 1}个表格`);
          const worksheet = XLSX.utils.table_to_sheet(table);
          const sheetName = `表格${index + 1}`;
          XLSX.utils.book_append_sheet(workbook, worksheet, sheetName);
          console.log(`表格${index + 1}处理成功`);
        } catch (error) {
          console.warn(`表格${index + 1}导出失败:`, error);
        }
      });
    } else {
      console.log('没有找到表格，尝试提取文本内容');
      // 如果没有表格，尝试提取文本内容
      const textData = extractTextData(element);
      if (textData.length > 0) {
        console.log('提取到文本数据条数:', textData.length);
        const worksheet = XLSX.utils.json_to_sheet(textData);
        XLSX.utils.book_append_sheet(workbook, worksheet, '页面内容');
      } else {
        console.log('没有提取到文本数据，创建基本信息表');
        // 如果没有结构化数据，创建一个基本的工作表
        const basicData = [
          { '导出时间': new Date().toLocaleString() },
          { '页面标题': document.title || '电池数据管理' },
          { '说明': '页面中未找到可导出的表格数据' }
        ];
        const worksheet = XLSX.utils.json_to_sheet(basicData);
        XLSX.utils.book_append_sheet(workbook, worksheet, '导出信息');
      }
    }

    console.log('工作簿创建完成');
    return workbook;
  };

  // 提取页面文本数据
  const extractTextData = (element) => {
    const data = [];
    
    // 尝试提取一些有用的文本信息
    const headings = element.querySelectorAll('h1, h2, h3, h4, h5, h6');
    const paragraphs = element.querySelectorAll('p');
    const listItems = element.querySelectorAll('li');

    headings.forEach((heading, index) => {
      if (heading.textContent.trim()) {
        data.push({
          '类型': '标题',
          '序号': index + 1,
          '内容': heading.textContent.trim()
        });
      }
    });

    paragraphs.forEach((p, index) => {
      if (p.textContent.trim() && p.textContent.length < 200) {
        data.push({
          '类型': '段落',
          '序号': index + 1,
          '内容': p.textContent.trim()
        });
      }
    });

    return data.slice(0, 50); // 限制数据量
  };

  return (
    <Button
      type="primary"
      icon={<DownloadOutlined />}
      loading={loading}
      onClick={handleExport}
      style={{
        borderRadius: '6px',
        boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
        ...style
      }}
    >
      {loading ? '导出中...' : '导出Excel'}
    </Button>
  );
};

export default ExportButton; 